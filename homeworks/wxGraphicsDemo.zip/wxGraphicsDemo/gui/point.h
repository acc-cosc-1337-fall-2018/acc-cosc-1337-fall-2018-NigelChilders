#ifndef POINT_H
#define POINT_H


#endif // !POINT_H